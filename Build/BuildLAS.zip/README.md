# LeagueAssault - headers and functions

This package serves as an easy way to compile mods against LeagueAS140, providing extensibility through defined headers and functions.